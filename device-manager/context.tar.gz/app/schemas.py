from pydantic import BaseModel
from typing import List, Optional

# Zone schemas
class ZoneBase(BaseModel):
    name: str

class ZoneCreate(ZoneBase):
    room_id: int

class ZoneUpdate(ZoneBase):
    pass

class Zone(ZoneBase):
    id: int
    room_id: int

    class Config:
        orm_mode = True

# Room schemas
class RoomBase(BaseModel):
    name: str

class RoomCreate(RoomBase):
    floor_id: int

class RoomUpdate(RoomBase):
    pass

class Room(RoomBase):
    id: int
    floor_id: int
    zones: List[Zone] = []

    class Config:
        orm_mode = True

# Floor schemas
class FloorBase(BaseModel):
    name: str

class FloorCreate(FloorBase):
    site_id: int

class FloorUpdate(FloorBase):
    pass

class Floor(FloorBase):
    id: int
    site_id: int
    rooms: List[Room] = []

    class Config:
        orm_mode = True

# Site schemas
class SiteBase(BaseModel):
    name: str
    address: Optional[str] = None
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    icon_name: Optional[str] = None

class SiteCreate(SiteBase):
    pass

class SiteUpdate(SiteBase):
    pass

class Site(SiteBase):
    id: int
    floors: List[Floor] = []

    class Config:
        orm_mode = True

from pydantic import BaseModel
from typing import Optional

class DeviceOut(BaseModel):
    deveui: str
    device_type_id: Optional[int]
    location1: Optional[str]
    location2: Optional[str]
    location3: Optional[str]
    last_gateway: Optional[str]
    zone_id: Optional[int]

    class Config:
        orm_mode = True
