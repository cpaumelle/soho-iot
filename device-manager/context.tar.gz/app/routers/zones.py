from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app import schemas, models, database

router = APIRouter(prefix="/zones", tags=["zones"])

@router.post("/", response_model=schemas.Zone, status_code=status.HTTP_201_CREATED)
def create_zone(zone: schemas.ZoneCreate, db: Session = Depends(database.get_db)):
    # Verify the room exists
    room = db.query(models.Room).filter(models.Room.id == zone.room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    db_zone = models.Zone(**zone.dict())
    db.add(db_zone)
    db.commit()
    db.refresh(db_zone)
    return db_zone

@router.put("/{zone_id}", response_model=schemas.Zone)
def update_zone(zone_id: int, zone: schemas.ZoneUpdate, db: Session = Depends(database.get_db)):
    db_zone = db.query(models.Zone).filter(models.Zone.id == zone_id).first()
    if not db_zone:
        raise HTTPException(status_code=404, detail="Zone not found")
    for key, value in zone.dict(exclude_unset=True).items():
        setattr(db_zone, key, value)
    db.commit()
    db.refresh(db_zone)
    return db_zone

@router.delete("/{zone_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_zone(zone_id: int, db: Session = Depends(database.get_db)):
    db_zone = db.query(models.Zone).filter(models.Zone.id == zone_id).first()
    if not db_zone:
        raise HTTPException(status_code=404, detail="Zone not found")
    db.delete(db_zone)
    db.commit()
    return None
