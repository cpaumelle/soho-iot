from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models import Device
from app.schemas import DeviceOut

router = APIRouter(prefix="/devices/api/test")

@router.get("/devices", response_model=List[DeviceOut])
def get_all_devices_test(db: Session = Depends(get_db)):
    print("📡 [TEST] /devices-test called")
    devices = db.query(Device).all()
    print(f"📦 [TEST] returned {len(devices)} devices")
    return devices

@router.get("/ping")
def ping():
    return {"ping": "pong"}
