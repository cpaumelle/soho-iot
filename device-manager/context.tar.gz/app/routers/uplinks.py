from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Uplink

router = APIRouter()

@router.get("/uplinks")
def get_all_uplinks(db: Session = Depends(get_db)):
    try:
        uplinks = db.query(Uplink).all()
        return uplinks
    except Exception as e:
        return {"error": str(e), "message": "Database schema mismatch"}
