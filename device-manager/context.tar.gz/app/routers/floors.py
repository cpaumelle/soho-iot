from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app import schemas, models, database

router = APIRouter(prefix="/floors", tags=["floors"])

@router.get("/{floor_id}/rooms", response_model=List[schemas.Room])
def get_rooms(floor_id: int, db: Session = Depends(database.get_db)):
    rooms = db.query(models.Room).filter(models.Room.floor_id == floor_id).all()
    return rooms

@router.post("/", response_model=schemas.Floor, status_code=status.HTTP_201_CREATED)
def create_floor(floor: schemas.FloorCreate, db: Session = Depends(database.get_db)):
    # Verify the site exists
    site = db.query(models.Site).filter(models.Site.id == floor.site_id).first()
    if not site:
        raise HTTPException(status_code=404, detail="Site not found")
    
    db_floor = models.Floor(**floor.dict())
    db.add(db_floor)
    db.commit()
    db.refresh(db_floor)
    return db_floor

@router.put("/{floor_id}", response_model=schemas.Floor)
def update_floor(floor_id: int, floor: schemas.FloorUpdate, db: Session = Depends(database.get_db)):
    db_floor = db.query(models.Floor).filter(models.Floor.id == floor_id).first()
    if not db_floor:
        raise HTTPException(status_code=404, detail="Floor not found")
    for key, value in floor.dict(exclude_unset=True).items():
        setattr(db_floor, key, value)
    db.commit()
    db.refresh(db_floor)
    return db_floor

@router.delete("/{floor_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_floor(floor_id: int, db: Session = Depends(database.get_db)):
    db_floor = db.query(models.Floor).filter(models.Floor.id == floor_id).first()
    if not db_floor:
        raise HTTPException(status_code=404, detail="Floor not found")
    db.delete(db_floor)
    db.commit()
    return None
