from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app import schemas, models, database

router = APIRouter(prefix="/sites", tags=["sites"])

@router.get("/", response_model=List[schemas.Site])
def get_sites(db: Session = Depends(database.get_db)):
    sites = db.query(models.Site).all()
    return sites

@router.get("/{site_id}/floors", response_model=List[schemas.Floor])
def get_floors(site_id: int, db: Session = Depends(database.get_db)):
    floors = db.query(models.Floor).filter(models.Floor.site_id == site_id).all()
    return floors

@router.post("/", response_model=schemas.Site, status_code=status.HTTP_201_CREATED)
def create_site(site: schemas.SiteCreate, db: Session = Depends(database.get_db)):
    db_site = models.Site(**site.dict())
    db.add(db_site)
    db.commit()
    db.refresh(db_site)
    return db_site

@router.put("/{site_id}", response_model=schemas.Site)
def update_site(site_id: int, site: schemas.SiteUpdate, db: Session = Depends(database.get_db)):
    db_site = db.query(models.Site).filter(models.Site.id == site_id).first()
    if not db_site:
        raise HTTPException(status_code=404, detail="Site not found")
    for key, value in site.dict(exclude_unset=True).items():
        setattr(db_site, key, value)
    db.commit()
    db.refresh(db_site)
    return db_site

@router.delete("/{site_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_site(site_id: int, db: Session = Depends(database.get_db)):
    db_site = db.query(models.Site).filter(models.Site.id == site_id).first()
    if not db_site:
        raise HTTPException(status_code=404, detail="Site not found")
    db.delete(db_site)
    db.commit()
    return None
